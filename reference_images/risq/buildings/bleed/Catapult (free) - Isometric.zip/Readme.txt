The Free version only contains 1 Animations out of four.
- No other restrictions.

Support the creator by purchasing the complete pack here: https://remos.itch.io/medieval-catapult

Author can be contacted via e-mail at valarinPath@gmail.com
Copyright © 2017 Remos Turcuman